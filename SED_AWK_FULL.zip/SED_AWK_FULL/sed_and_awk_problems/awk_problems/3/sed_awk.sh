#!/bin/bash

mapping_file="$1"
paragraph_file="$2"

awk -F: '{ 
    print "s/student_name/" $1 "/g; s/roll_no/" $2 "/g";
}' "$mapping_file" | while read sed_command; do
    sed "$sed_command" "$paragraph_file"
    echo  # Extra line gap between paragraphs
done

# only awk
# #!/bin/bash

# awk -F: '{
#     while ((getline line < ARGV[2]) > 0) {
#         gsub("student_name", $1, line);
#         gsub("roll_no", $2, line);
#         print line;
#     }
#     close(ARGV[2]);
#     print "";  # Extra line gap
#}' "$1" "$2"
# only sed
# #!/bin/bash

# mapping_file="$1"
# paragraph_file="$2"

# # Generate sed commands from the mapping file
# sed_cmds=$(sed 's/\(.*\):\(.*\)/s\/student_name\/\1\/g; s\/roll_no\/\2\/g/' "$mapping_file")

# # Apply each set of sed commands to the paragraph file and add an extra newline
# while IFS= read -r cmd; do
#     sed "$cmd" "$paragraph_file"
#     echo  # Extra line gap between paragraphs
# done <<< "$sed_cmds"