import sys

def rotate(matrix):
    n=len(matrix)
    matrix2 = [[0 for i in range(n)]for j in range(n)]
    for i in range(n):
        for j in range(n):
            matrix2[i][j]+=matrix[j][n-i-1]
    
    
    return matrix2  
          
result = rotate(eval(sys.argv[1]))
print(result)                     