with open("q2-input.txt", "r") as file:
    union_set = set()
    for line in file:
        elements = line.strip().split(',')
        for element in elements:
            if element.strip():  # ignore empty strings
                union_set.add(int(element.strip()))
print(len(union_set))