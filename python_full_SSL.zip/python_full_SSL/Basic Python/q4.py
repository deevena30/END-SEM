with open("q4-input.txt", "r") as f:
    lines = f.readlines()

if len(lines) < 2:
    print("INVALID INPUT")
    exit()

s = lines[0].strip()
perm_line = lines[1].strip()

try:
    perm = list(map(int, perm_line.split()))
except ValueError:
    print("INVALID INPUT")
    exit()

if len(perm) != len(s) or sorted(perm) != list(range(len(s))):
    print("INVALID INPUT")
else:
    result = ''.join(s[i] for i in perm)
    print(result)
