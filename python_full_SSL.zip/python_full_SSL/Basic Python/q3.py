entries = []
with open("buggy_marksheet.txt",'r') as f:
   for roll_marks in f:
       roll_marks=roll_marks.strip()
       roll=roll_marks.split(" ")[0].strip()
       marks=int(roll_marks.split(" ")[1].strip())
       rollno=roll.split("_")
       section=int(rollno[2])
       entries.append((section, -marks, roll_marks))
       
entries_Sorted = sorted(entries)

with open("output.txt", "w") as outfile:
        for _, _, line in entries_Sorted:
            outfile.write(line + "\n")