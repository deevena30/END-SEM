#!/bin/bash

arr=("$@")
n="$#"

if [[ $# -eq 0 ]]; then
    echo "provide an array of numbers."
    exit 1
fi

count=0
for ((i=0; i<n; i++)); do
    for ((j = 0; j < n - i - 1; j++)); do
        if (( ${arr[j]} > ${arr[j+1]} )); then
            temp=${arr[j]}
            arr[j]=${arr[j+1]}
            arr[j+1]=$temp
            ((count++))
        fi
    done
done

echo "${arr[@]}"
echo "$count"



