#!/bin/bash
file=$1

declare -A fruits
for word in $(cat $file); do
    (( fruits["$word"]+=1 ))
done


for key in "${!fruits[@]}"; do
    echo "$key : ${fruits["$key"]}"
done

#OR
#line tharvatha new line untene idhi work ayithadhi
#!/bin/bash
file=$1

declare -A fruits

while read -r line; do
    for word in $line; do
    (( fruits["$word"]+=1 ))
    done
done < "$file"

for key in "${!fruits[@]}"; do
    echo "$key : ${fruits["$key"]}"
done