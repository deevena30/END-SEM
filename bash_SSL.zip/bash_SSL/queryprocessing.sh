#!/bin/bash

q="$1"
shift
arr=("$@")
n=${#arr[@]}

bool=0

for (( i=0; i<n; i++ )) ; do
    if(( q == arr[i] )); then
        bool=1
        break
    fi
done

if [[ $bool -eq 1 ]]; then
    echo YES
else
    echo NO
fi