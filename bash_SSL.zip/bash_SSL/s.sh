#!/bin/bash

path="$1"
log_file="log.txt"
count=0

> "$log_file"

for file in "$path"/*.py; do
    if [[ -f "$file" ]]; then
        filename=$(basename "$file")
        echo "Deleted $filename" >> "$log_file"
        rm -f "$filename"
        count=$((count + 1))
    fi
done

echo "$count"
