#!/bin/bash

mkdir -p output
today="26112008"

for file in *.jpg; do
    if [[ "$file" =~ ^([A-Za-z]+)([0-9]{8})\.jpg$ ]]; then
        name="${BASH_REMATCH[1]}"
        date="${BASH_REMATCH[2]}"

        if [[ "$date" -eq "$today" ]]; then
            suffix="_today"
        elif [[ "$date" -ge "19112008" && "$date" -le "25112008" ]]; then
            suffix="_weekold"
        elif [[ "$date" -le "18112008" ]]; then
            suffix="_quiteold"
        elif [[ "$date" -ge "27112008" ]]; then
            rm -f "$file"
            continue
        else
            continue
        fi

        cp "$file" "output/${name}${date}${suffix}.jpg"
    fi
done
