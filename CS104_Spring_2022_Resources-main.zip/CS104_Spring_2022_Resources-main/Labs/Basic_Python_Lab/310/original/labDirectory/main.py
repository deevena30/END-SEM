'''
    Sieve of Eratosthenes
'''

import sys

# read the parameter from command line using sys


# your implementation for printing the list of prime numbers

