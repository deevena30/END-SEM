#! /bin/bash

python3 main.py
python3 autograder.py
rm -rf plot.png