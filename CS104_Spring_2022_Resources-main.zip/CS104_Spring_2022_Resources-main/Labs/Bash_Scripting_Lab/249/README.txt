Purpose of this part is append a particular string to ALL .out files present in the directory same as submission.sh

Examples :- if the submission.sh is executed as "./submission.sh Hello CSE Freshies!" then the .out files (which is a.out in this case) should have "Hello CSE Freshies!" appended to it.

Note : ./submission.sh <arg1> <arg2> <arg3> ... these are command line arguments, all the command line arguments will form that one string which you need to append.

Side Note : .out files include files like a.py.out, a.py.out.out etc.

To see your correctness of program, goto 249/evaluationScripts/ directory (using cd command) and run "./evaluate.sh", all the comments and evaluation will come on the 
terminal or in "evaluate.json".

If there is a permission denied problem, do "chmod +x evaluate.sh" first.

In case of any problem with autograder, please contact me.