Purpose of this part is perform simple arithmetic operations using bash.

Examples :- if the submission.sh is executed as "./submission.sh max 3 56 1 9 8", then program should print out maximum of {3, 56, 1, 9, 8} which is 56, similarly there will be inputs like "min", "avg" and "sum"

Note : ./submission.sh <arg1> <arg2> <arg3> ... these are command line arguments, the very first command line will be one of {"max", "min", "sum", "avg"} and the following arguments will the numbers on which you have to perform the operation.

Side Note : ANY number of numbers can be passed through the command line input.

To see your correctness of program, goto 250/evaluationScripts/ directory (using cd command) and run "./evaluate.sh", all the comments and evaluation will come on the 
terminal or in "evaluate.json".

If there is a permission denied problem, do "chmod +x evaluate.sh" first.

In case of any problem with autograder, please contact me.