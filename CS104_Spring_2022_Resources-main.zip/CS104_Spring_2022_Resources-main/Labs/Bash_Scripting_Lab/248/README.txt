Purpose of this part is convert all lowercase alphabets to uppercase.

There is a README in testcases/, make sure to read that.

To see your correctness of program, goto 248/evaluationScripts/ directory (using cd command) and run "./evaluate.sh", all the comments and evaluation will come on the 
terminal or in "evaluate.json".

If there is a permission denied problem, do "chmod +x evaluate.sh" first.

In case of any problem with autograder, please contact me.