'''
    Distributions
'''

import numpy as np
from matplotlib import pyplot as plt

# take samples from each of the distributions and plot the sub-plot histogram
# use the numpy random library

# save your plot in the end
plt.savefig('plot.png')
