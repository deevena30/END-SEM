#! /bin/bash

python3 autograder.py
rm -rf out.txt
