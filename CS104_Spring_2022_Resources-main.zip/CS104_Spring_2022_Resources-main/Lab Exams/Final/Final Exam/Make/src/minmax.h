int maximum(int[], int);
int minimum(int[], int);