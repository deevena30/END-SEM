Standard text
