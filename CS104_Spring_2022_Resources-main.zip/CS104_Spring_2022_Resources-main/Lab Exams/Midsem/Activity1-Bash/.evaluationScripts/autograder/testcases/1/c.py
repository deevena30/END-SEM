inport numpy as np
