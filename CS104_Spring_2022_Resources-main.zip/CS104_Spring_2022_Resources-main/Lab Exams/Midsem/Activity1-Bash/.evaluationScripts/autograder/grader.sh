#! /bin/bash
python script.py
