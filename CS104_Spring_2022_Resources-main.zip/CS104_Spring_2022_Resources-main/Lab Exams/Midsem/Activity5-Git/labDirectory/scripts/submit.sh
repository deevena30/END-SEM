#!/bin/bash

cd ../

tar -zcvf repo.tar.gz repo/

cd scripts

rm -rf ../repo/