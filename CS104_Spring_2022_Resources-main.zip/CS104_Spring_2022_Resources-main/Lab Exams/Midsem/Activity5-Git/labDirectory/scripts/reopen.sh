#!/bin/bash

rm -rf ../repo 2>/dev/null

tar -xvzf ../repo.tar.gz --directory ../