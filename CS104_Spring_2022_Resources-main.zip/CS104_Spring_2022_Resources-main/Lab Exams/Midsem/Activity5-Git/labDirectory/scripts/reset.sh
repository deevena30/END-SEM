#!/bin/bash

# Reset file contents

rm -rf ../repo/

tar -zxvf repo.tar.gz --directory ../